from django.db import models

class showManager(models.Manager):
    def basic_validator(self,postdata):
        errors = {}
        if len(postdata['show_title']) < 2 :
            errors ['show_title'] = "title name should be at least 2 characters"
        if len(postdata['show_network']) < 3 :
            errors ['show_network'] = "network name should be at least 3 characters"
        if len(postdata['show_desc']) < 10 :
            errors ['show_desc']  = "Description should be at least 10 characters"        
        return errors       

class shows(models.Model):
    show_title = models.CharField(max_length=255)
    show_network = models.CharField(max_length=255)
    show_desc = models.CharField(max_length=255)
    show_date = models.DateField(default=None)
    created_at = models.DateTimeField(auto_now=True )
    updated_at = models.DateTimeField(auto_now=True)

def get_all_shows():
    return shows.objects.all()

def create_show(request):
    show_title = request.POST['show_title']
    show_network = request.POST['show_network']
    show_date = request.POST['show_date']
    show_desc = request.POST['show_desc']
    new_show = shows.objects.create(show_title = show_title, show_network = show_network, show_desc=show_desc, show_date=show_date ) 
    return new_show

def delete_show(request):
    shows.objects.get(id)
