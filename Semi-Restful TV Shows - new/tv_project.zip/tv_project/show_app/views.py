from django.shortcuts import render, HttpResponse, redirect
from . import models
from .models import shows

def create(request):
    return render(request,'create.html')

def create_show(request):
    models.create_show(request)
    return redirect('/') 

def UpdateShow(request,uid):
    show_to_update = models.shows.objects.get(id=uid) 
    if request.POST:
        show_to_update.show_title= request.POST['show_title']
        show_to_update.show_network= request.POST['show_network']
        show_to_update.show_date= request.POST['show_date']
        show_to_update.show_desc= request.POST['show_desc']
        show_to_update.save()
        return redirect('/shows')

def mainshows(request):
    context = {
        "shows_information": models.get_all_shows()
    }
    return render (request,'read.html',context)

def delete_show(request,uid):
    show_to_delete = models.shows.objects.get(id=uid)
    show_to_delete.delete()
    return redirect ('/shows')

def show_information(request,uid):
    
    context = {
        "shows_information1": models.shows.objects.get(id=uid)
    }
    return render (request,'shows_id.html',context)
def editShow(request,uid):
    data = {
        'show' : models.shows.objects.get(id=uid) 
    }
    return render(request,"edit.html",data)
