from django.apps import AppConfig


class GameappConfig(AppConfig):
    name = 'gameapp'
