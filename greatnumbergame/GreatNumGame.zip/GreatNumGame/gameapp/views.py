from django.shortcuts import render, HttpResponse,redirect
import random
x=random.randint(1, 100) 		
print(x)
def index(request):
    print(x)
    return render(request,'index.html')
def result(request):
    numberfromform=request.POST['guessednumber']
    if ( x == int(numberfromform)):
        return render(request,("correct.html"))
    elif ( x > int(numberfromform)):
        return render(request,("toolow.html"))
    elif ( x < int(numberfromform)):
        return render(request,("toohigh.html"))
    else:
        return redirect('/')
        
              
