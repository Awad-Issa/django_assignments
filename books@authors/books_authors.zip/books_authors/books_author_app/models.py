from django.db import models
# Create your models here.coe 
class Book(models.Model):
    title = models.CharField(max_length=255)
    desc = models.TextField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

class Author(models.Model):
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    notes = models.TextField(default="no notes")
    books = models.ManyToManyField(Book, related_name="authors")
 
def get_all_books():
    return Book.objects.all()

def get_all_authors():
    return Author.objects.all()

def add_book(request):
    title = request.POST['title']
    desc = request.POST['desc']
    new_book = Book.objects.create(title=title,desc=desc)
    return new_book

def add_author(request):
    first_name = request.POST['first_name']
    last_name = request.POST['last_name']
    notes = request.POST['notes']    
    new_author = Author.objects.create(first_name=first_name,last_name=last_name,notes=notes)    
    return new_author

# def bookdetailes(request):
#     details_book = Book.objects.get()