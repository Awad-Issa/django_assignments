from django.shortcuts import render, HttpResponse, redirect
from . import models

# Create your views here.
from django.shortcuts import render, HttpResponse
def index(request):
    context={
        "booksinformation":models.get_all_books()
    }
    return render(request,'index.html',context)

def index2(request):
    context={
        "authorsinformation":models.get_all_authors()
    }
    return render(request,'index2.html',context)

def author_details(request,num):
    context={
        'author_details':models.Author.objects.get(id=num)
    }
    return render(request,'authors.html',context)

def book_details(request,num):
    context={
        'book_details':models.Book.objects.get(id=num)
    }
    return render(request,'books.html',context)

def add_book(request):
    models.add_book(request)
    return redirect('/')

def add_author(request):
    models.add_author(request)
    return redirect('/authors')    

