from django.urls import path     
from . import views
urlpatterns = [
    path('', views.index),
    path('authors',views.index2),
    path('createauthors',views.add_author),
    path('add_book',views.add_book),
    path('author/<int:num>',views.author_details),
    path('book/<int:num>',views.book_details),

]
