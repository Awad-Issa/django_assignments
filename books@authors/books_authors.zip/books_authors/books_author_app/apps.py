from django.apps import AppConfig


class BooksAuthorAppConfig(AppConfig):
    name = 'books_author_app'
